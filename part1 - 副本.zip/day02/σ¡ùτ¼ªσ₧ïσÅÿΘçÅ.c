#include <stdio.h>

int main()
{
   char ch1='A';
   char ch2=90;
   printf("ch1的类型是:%c\n",ch1);//字符型取值是-128~127
   printf("ch2的类型是:%c\n",ch2);

    return 0;

}