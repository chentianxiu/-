#include <stdio.h>

int main()
{
    int a=5.0/3;
    float b=5.0/3;
    printf("a:%d\t\tb:%f",a,b);

    return 0;

}