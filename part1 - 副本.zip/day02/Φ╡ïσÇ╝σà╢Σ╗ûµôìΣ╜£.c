#include <stdio.h>

int main()
{
   int num;
   printf("num=%d\n",num);

    return 0;

}