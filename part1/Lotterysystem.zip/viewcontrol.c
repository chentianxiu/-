#include "viewcontrol.h"

/*
	功能：注界面控制函数
	参数：userHead: 用户头节点
	返回值：无
*/
void mainViewControl(UserLink* userHead,UserLottery* lotteryHead,IssueLink* issueHead)
{
	if(NULL == userHead||NULL == lotteryHead||NULL == issueHead){
		return ;
	}	
	int choice = 0;
	while(1){
		//system("cls");//清屏
		mainView();		//住界面
		scanf("%d", &choice);
		switch(choice){
			case 1:			//注册
				//注册函数
				registerUser(userHead);
				break;
			case 2:			//登录
				userLogin(userHead,lotteryHead,issueHead);
				break;		
			case 0:			//退出
				return ;
			default:		
				break;
		}
	}
}

// 等待用户按下 Enter 键
void keyEnter() {
    printf("Press Enter to continue...\n");
    while (getchar() != '\n'); // 等待输入 Enter
}

//登录验证
void  userLogin(UserLink* userHead,UserLottery* lotteryHead,IssueLink* issueHead){

}

/*
	功能：普通用户二级界面显示
	参数：无
	返回值：无
*/
void userSecondViewControl(UserLink* userHead,UserLottery* lotteryHead,IssueLink* issueHead){

}