#include "issueLink.h"
#include<stdio.h>

/*
	功能：创建每期彩票链表
	参数：无
	返回值：头节点的地址 NULL 失败
*/
IssueLink* createIssueLink(){
    //创建头指针
     IssueLinklist header =NULL;
     //动态创建一个空间
     header = (IssueLink*)malloc(sizeof(IssueLink));
     //判断内存是否创建成功
     if (header == NULL){
         printf("内存创建失败\n");
         return NULL;
     }
     //空节点，将next域置空
     header->next = NULL;
     return header;
}

/*
	功能：添加节点
	参数：head: 头节点 newNode:要添加的节点
	返回值：	1 成功 0 失败
*/
void insertIssueNode(IssueLinklist head, IssueLinklist newNode){
    //找到尾部节点
    while (head->next!=NULL)
    {
        head = head->next;
    }
    //尾插操作
    newNode->next =head->next;
    head->next = newNode;
    return;
}

/*
	功能：打印所有信息
	参数：head: 头节点
	返回值：无
*/
void printIssueLink(IssueLinklist head){
    IssueLink *current = head->next;//定义一个中间变量
    while (current!=NULL)
    {
        printf("发布期号:%d\t\t彩票单价:%.2lf\t\t开奖状态:%d\t\t中奖号码:%s\t\t售出总数:%d\t\t奖池总额:%.2lf\n",
        current->data.issue,current->data.saleprice,current->data.winningStatus,current->data.winNumber,current->data.salenum,current->data.pool);
        current = current->next;
    }
    return;
}

/*
	功能：释放所有节点
	参数：head: 头节点
	返回值：无
*/
void freeIssueLink(IssueLink* head){
    IssueLink *current = head;//定义一个中间变量
    while (current!=NULL)
    {
        IssueLink *temp = current;
        current = current->next;
        free(temp);
    }
    return;
}

/*
	功能：保存所有信息到文件中
	参数：head 头节点
	返回值：无
*/
void saveIssueLink(IssueLink* head){
    FILE *file = fopen("issueLink.txt", "w");
    if (file == NULL)
    {
        printf("文件保存失败\n");
        return;
    }
    IssueLink * current = head->next;//定位到首元节点

    while (current!=NULL)
    {
        fprintf(file,"发布期号:%d\t\t彩票单价:%.2lf\t\t开奖状态:%d\t\t中奖号码:%s\t\t售出总数:%d\t\t奖池总额:%.2lf\n",
        current->data.issue,current->data.saleprice,current->data.winningStatus,current->data.winNumber,current->data.salenum,current->data.pool);
        current = current->next;
    }
    fclose(file);
}

/*
	功能：从文件中加载所有的信息到内存中
	参数：head: 头节点
	返回值：无
*/
void loadIssueLink(IssueLink* head){
    FILE *file = NULL;

    file = fopen("issueLink.txt", "r");

    if (file == NULL)
    {
        printf("每期彩票文件打开失败\n");
        return;
    }
    int		issue; //发布期号
	double	saleprice;//彩票单价
	int winningStatus; //开奖状态
	char winNumber[10];//中奖号码
	int  salenum;//售出总数
	double	pool;//奖池总额

    while (fscanf(file,"发布期号:%d\t\t彩票单价:%.2lf\t\t开奖状态:%d\t\t中奖号码:%s\t\t售出总数:%d\t\t奖池总额:%.2lf\n",
        &issue,&saleprice,&winningStatus,winNumber,&salenum,&pool)!= EOF)
    {
        IssueLink *newNode = createIssueLink();
        newNode->data.issue = issue;
        newNode->data.saleprice =saleprice;
        newNode->data.pool = pool;
        newNode->data.winningStatus = winningStatus;
        newNode->data.salenum =salenum;
        strcpy(newNode->data.winNumber,winNumber);
        insertIssueNode(head,newNode);
    }
    fclose(file);
}