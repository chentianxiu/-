#ifndef VIEWCONTROL_H_
#define VIEWCONTROL_H_

#include "userLink.h"
#include "userLottery.h"
#include "issueLink.h"
#include "view.h"

/*
	功能：注界面控制函数
	参数：userHead: 用户头节点
	返回值：无
*/
void mainViewControl(UserLink* userHead,UserLottery* lotteryHead,IssueLink* issueHead);

// 等待用户按下 Enter 键
void keyEnter();
/*
	功能：普通用户二级界面显示
	参数：无
	返回值：无
*/
void userSecondViewControl(UserLink* userHead,UserLottery* lotteryHead,IssueLink* issueHead);


//登录验证
void  userLogin(UserLink* userHead,UserLottery* lotteryHead,IssueLink* issueHead);

#endif