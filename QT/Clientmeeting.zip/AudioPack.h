#ifndef AUDIOPACK_H
#define AUDIOPACK_H


typedef struct
{
    int dataLen;
    char data[1024];
}AudioPackage;


#endif // AUDIOPACK_H
