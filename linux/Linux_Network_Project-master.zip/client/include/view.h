/*

菜单视图头文件

Author : Renleilei
Date   : 2016-12-10
Version: 1.0

*/

#ifndef _VIEW_H
#define _VIEW_H

void mainMenu(void);

void userMenu(void);

#endif
